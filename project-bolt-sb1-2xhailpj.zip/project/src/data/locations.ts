export const serviceLocations = [
  {
    city: 'Mumbai',
    areas: ['Andheri', 'Bandra', 'Powai', 'Worli', 'Juhu']
  },
  {
    city: 'Delhi',
    areas: ['Connaught Place', 'Dwarka', 'Rohini', 'Saket', 'Vasant Kunj']
  },
  {
    city: 'Bangalore',
    areas: ['Koramangala', 'Indiranagar', 'Whitefield', 'HSR Layout', 'JP Nagar']
  }
];