export const evBrands = [
  {
    id: 'ola',
    name: 'Ola Electric',
    models: ['S1 Pro', 'S1 Air', 'S1X']
  },
  {
    id: 'ather',
    name: 'Ather Energy',
    models: ['450X', '450 Plus', '450']
  },
  {
    id: 'vida',
    name: 'VIDA',
    models: ['V1 Pro', 'V1 Plus']
  },
  {
    id: 'revolt',
    name: 'Revolt Motors',
    models: ['RV400', 'RV300']
  },
  {
    id: 'tvs',
    name: 'TVS Electric',
    models: ['iQube', 'iQube S', 'iQube ST']
  }
];