export const testimonials = [
  {
    id: 1,
    name: 'Rahul Sharma',
    comment: 'Exceptional service! The team arrived within 10 minutes for my emergency repair.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d'
  },
  {
    id: 2,
    name: 'Priya Patel',
    comment: 'Very professional team. They fixed my Ather 450X in no time!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330'
  },
  {
    id: 3,
    name: 'Amit Kumar',
    comment: 'Great subscription plans. The gold membership is totally worth it.',
    rating: 4,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d'
  }
];